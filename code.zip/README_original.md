# EDEM 2026 粒子形状缩放 (Shape Scale) API/UDL 模板

这个压缩包的核心目的：
- 用 **EDEM 2026** 的新特性“Particle Shape Scale（sx,sy,sz）”实现你图里那种
  **ONLY 1 particle type ↔ 3 shapes**（同一种颗粒类型，生成时按不同轴向比例拉伸/压扁）。

最关键的发现来自你在安装目录 `src` 里找到的头文件：
- `C:\Program Files\Altair\2026\EDEM\src\Api\Core\NFactoryTypesV3_10_0.h`
- 里面的 `NFactoryTypesV3_10_0::SNewParticleData` 结构体新增了成员：
  - `NApiHelpers::CSimple3DVector shapeScale;`  // 说明：对角缩放 xx,yy,zz

也就是说：**不需要你再去找某个 setShapeScale(...) 函数**。
在 Particle Factory UDL 里创建新粒子时，直接给 `np.shapeScale` 赋值就行。

---

## 你拿来就能用的“核心代码”

在你的 Factory UDL 的 `createParticle(...)` 里，做这一句：

```cpp
np.shapeScale = {sx, sy, sz};
```

本包已在 `src/ApiAdapter.h` 里封装成：

```cpp
EDEM2026::setNewParticleShapeScale(np, sx, sy, sz);
```

---

## 本包实现的思路（推荐且与截图一致）

**Particle Factory**（最符合你截图）
- 生成时“一种类型 → 多种形状”
- 关键：在 `createParticle(...)` 里通过 `SNewParticleData.shapeScale` 设置每个新粒子轴向缩放
- 本包文件：
  - `src/ParticleShapeScaleFactory.h`
  - `src/ParticleShapeScaleFactory.cpp`
  - `src/ParticleShapeScaleFactoryCore.cpp`  （导出 GETFACT* 三个函数）

---

## 如何把 1 种类型变 3 种形状（示例）

`ParticleShapeScaleFactory.cpp` 默认给了 3 套 shapeScale：
- (1.0, 1.0, 1.0)  原始
- (0.7, 0.7, 1.8)  Z 方向拉伸（更“细长”）
- (1.8, 1.8, 0.55) 压扁（更“扁平”）

默认实现为了演示清晰，会在**同一个时间步连续生成 3 个粒子**，
并按顺序循环使用这 3 套 shapeScale（即 1→2→3）。
如果你希望按权重随机抽样，只要把 `createParticle` 里 `k = m_createdThisStep % 3;`
改成 `k = m_pick(m_rng);` 即可。

---

## 保体积（Preserve Volume）

如果你想“形状变了，但体积/质量保持不变”，可以启用保体积归一化：

\[ sx\,sy\,sz = 1 \]

本包在 `ApiAdapter.h` 提供了：
- `normalizeShapeScaleVolume(sx,sy,sz)`

---

## 编译与加载（高层步骤）

EDEM 的 UDL 通常需要你用官方 examples/模板工程来建 VS 项目，然后把本包 `src/*.cpp` 加进去。
你安装目录里有 `examples` 文件夹，优先用里面的 Factory 示例工程作为起点。

大致流程：
1) 新建/复制一个 Particle Factory UDL 示例工程
2) 把以下文件加入项目：
   - `src/ParticleShapeScaleFactory.h/.cpp`
   - `src/ParticleShapeScaleFactoryCore.cpp`
   - `src/ApiAdapter.h`
3) Include 路径指向 `C:\Program Files\Altair\2026\EDEM\src`
4) 编译生成 dll
5) 在 EDEM 里加载对应 Factory UDL

---

## 你现在已找到的关键 API 位置（对应你 `findstr` 的结果）

- `Api\Core\NFactoryTypesV3_10_0.h`
  - `struct SNewParticleData` 里新增 `shapeScale` 字段
- `Api\Factories\IPluginParticleFactoryV3_10_0.h`
  - `EApiParticleFactoryFeatureFlags::usesShapeScale`
  - `createParticle(...)` 的完整函数签名
- `Api\Factories\PluginParticleFactoryCore.h`
  - 定义并要求导出 `GETFACTORYINSTANCE / RELEASEFACTORYINSTANCE / GETFACTINTERFACEVERSION`
