#pragma once
// (Optional) kept for backward compatibility with the .vcxproj include list.
// This project does not require extra adapters; all logic is in ParticleShapeScaleFactory.cpp.
