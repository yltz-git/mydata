#pragma once
// ParticleShapeScaleFactory - EDEM 2026 (API v3.10.0)
//
// Plugin Particle Factory that:
//   - Writes 3-axis shape scale: newParticleData.shapeScale = (sx, sy, sz)
//   - Samples (sx,sy,sz) independently in user ranges.
//   - Samples position uniformly in an axis-aligned box (boxMin/boxMax).
//   - Provides generation controls via TXT:
//       * startTime
//       * totalNumber (cap)
//       * totalMassKg (cap, needs a mass model)
//       * targetNumberPerSecond (rate)
//       * targetMassPerSecond (rate, needs a mass model)
//       * particlesPerTimeStep (fallback when no rate is used)
//
// IMPORTANT:
//   EDEM 2026 requires enabling feature flag usesShapeScale in setup(), otherwise shapeScale is ignored.

#include <random>

#include "Api/Factories/IPluginParticleFactoryV3_10_0.h"

class ParticleShapeScaleFactory final : public NApiFactory::IPluginParticleFactoryV3_10_0
{
public:
    ParticleShapeScaleFactory();
    ~ParticleShapeScaleFactory() override = default;

    void getPreferenceFileName(char prefFileName[NApi::FILE_PATH_MAX_LENGTH]) override;
    void setFilePath(const char simFile[]) override;

    bool setup(NApiFactory::NApiHelpers::CFlags<EApiParticleFactoryFeatureFlags>& featureFlags,
               const char prefFile[],
               char customMsg[NApi::ERROR_MSG_MAX_LENGTH]) override;

    bool starting() override;
    void stopping() override;

    NApi::ECalculateResult createParticle(const NApiFactory::NFactoryTypes::STimeStepData& timeStepData,
                                         bool& particleCreated,
                                         bool& additionalParticleRequired,
                                         NApiFactory::NFactoryTypes::SNewParticleData& newParticleData,
                                         NApiCore::ICustomPropertyDataApi_1_0* propData,
                                         NApiCore::ICustomPropertyDataApi_1_0* simData) override;

    void configForTimeStep(NApiCore::ICustomPropertyDataApi_1_0* simData) override;

    void getSmallestScale(double& scale, char type[NApi::API_BASIC_STRING_LENGTH]) const override;
    void getLargestScale(double& scale, char type[NApi::API_BASIC_STRING_LENGTH]) const override;

private:
    struct Range
    {
        double minV{1.0};
        double maxV{1.0};
    };

    // Shape scale ranges
    Range m_sx{0.8, 1.5};
    Range m_sy{0.9, 1.2};
    Range m_sz{0.85, 1.4};
    bool  m_preserveVolume{false};

    // Position box ranges (typical unit: meters)
    Range m_x{-0.5, 0.5};
    Range m_y{-0.5, 0.5};
    Range m_z{-0.5, 0.5};

    // Basic particle params
    double m_scale{1.0};
    char   m_typeName[NApi::API_BASIC_STRING_LENGTH]{};

    // Generation controls
    long long m_totalNumberLimit{0};
    double m_totalMassLimitKg{0.0};
    double m_startTime{0.0};

    double m_targetNumberPerSecond{0.0};
    double m_targetMassPerSecond{0.0};

    // Safe default: if preferences are not found, do NOT generate particles (avoid accidental explosions).
    int m_particlesPerTimeStep{0};
    int m_maxAttemptsToPlace{20};

    // Mass model (for totalMass/targetMass). If all are 0, mass-based controls are ignored.
    // Priority:
    //   1) massPerParticleKg
    //   2) baseMassKg (scaled by scale^3 and shape volume multiplier)
    //   3) densityKgPerM3 * baseVolumeM3 (scaled similarly)
    double m_massPerParticleKg{0.0};
    double m_baseMassKg{0.0};
    double m_densityKgPerM3{0.0};
    double m_baseVolumeM3{0.0};

    // Internal state
    double m_lastTime{-1.0};
    double m_prevStepTime{-1.0};
    int    m_createdThisStep{0};
    int    m_quotaThisStep{0};
    double m_rateCarry{0.0};

    unsigned long long m_totalCreated{0};
    double m_totalMassCreatedKg{0.0};

    std::mt19937_64 m_rng;

    char m_simFile[NApi::FILE_PATH_MAX_LENGTH]{};

private:
    // Returns true if a preference file was successfully loaded.
    bool loadPrefsIfPresent(const char* prefFilePath);

    static void normalizeToPreserveVolume(double& sx, double& sy, double& sz);
    double randUniform(double a, double b);

    int computeQuotaThisStep(double timeNow);
    double estimateParticleMassKg(double sx, double sy, double sz) const;
};
