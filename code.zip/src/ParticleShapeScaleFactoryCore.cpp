// Core exports required by EDEM for a Particle Factory plugin (API v3.10.0)
//
// EDEM searches for these symbols in the DLL:
//   - GETFACTORYINSTANCE
//   - RELEASEFACTORYINSTANCE
//   - GETFACTINTERFACEVERSION

#include "Api/Factories/PluginParticleFactoryCore.h"
#include "ParticleShapeScaleFactory.h"

namespace
{
    ParticleShapeScaleFactory* g_instance = nullptr;
}

EXPORT_MACRO NApiFactory::IPluginParticleFactory* GETFACTORYINSTANCE()
{
    if (!g_instance)
        g_instance = new ParticleShapeScaleFactory();
    return g_instance;
}

EXPORT_MACRO void RELEASEFACTORYINSTANCE(NApiFactory::IPluginParticleFactory* instance)
{
    // EDEM calls this when unloading the DLL
    auto* typed = dynamic_cast<ParticleShapeScaleFactory*>(instance);
    if (typed)
    {
        delete typed;
        if (typed == g_instance) g_instance = nullptr;
    }
}

EXPORT_MACRO int GETFACTINTERFACEVERSION()
{
    // v3.10.0 => 0x03.0A.00
    static const int INTERFACE_VERSION_MAJOR = 0x03;
    static const int INTERFACE_VERSION_MINOR = 0x0A;
    static const int INTERFACE_VERSION_PATCH = 0x00;

    return (INTERFACE_VERSION_MAJOR << 16 |
            INTERFACE_VERSION_MINOR << 8  |
            INTERFACE_VERSION_PATCH);
}
