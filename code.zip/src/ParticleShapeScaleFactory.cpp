#include "ParticleShapeScaleFactory.h"

#include <algorithm>
#include <cmath>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

namespace
{
    inline std::string trim(std::string s)
    {
        auto notSpace = [](unsigned char c) { return !std::isspace(c); };
        s.erase(s.begin(), std::find_if(s.begin(), s.end(), notSpace));
        s.erase(std::find_if(s.rbegin(), s.rend(), notSpace).base(), s.end());
        return s;
    }

    inline bool splitKeyValue(const std::string& line, std::string& key, std::string& value)
    {
        auto pos = line.find('=');
        if (pos == std::string::npos) return false;
        key = trim(line.substr(0, pos));
        value = trim(line.substr(pos + 1));
        return !key.empty();
    }

    inline bool parseBool01(const std::string& v, bool& out)
    {
        if (v == "1" || v == "true" || v == "TRUE" || v == "True") { out = true; return true; }
        if (v == "0" || v == "false" || v == "FALSE" || v == "False") { out = false; return true; }
        return false;
    }

    inline bool parseDoubles(const std::string& s, std::vector<double>& out)
    {
        out.clear();
        std::istringstream iss(s);
        double x;
        while (iss >> x) out.push_back(x);
        return !out.empty();
    }
}

ParticleShapeScaleFactory::ParticleShapeScaleFactory()
{
    std::snprintf(m_typeName, NApi::API_BASIC_STRING_LENGTH, "%s", "ParticleType1");
    std::memset(m_simFile, 0, sizeof(m_simFile));

    // Default seed: different every run
    std::random_device rd;
    m_rng.seed(((unsigned long long)rd() << 32) ^ (unsigned long long)rd());
}

double ParticleShapeScaleFactory::randUniform(double a, double b)
{
    if (a > b) std::swap(a, b);
    std::uniform_real_distribution<double> dist(a, b);
    return dist(m_rng);
}

void ParticleShapeScaleFactory::getPreferenceFileName(char prefFileName[NApi::FILE_PATH_MAX_LENGTH])
{
    // Relative to the plugin folder (EDEM will resolve it)
    std::snprintf(prefFileName, NApi::FILE_PATH_MAX_LENGTH, "%s", "config/ParticleShapeScaleFactoryPresets.txt");
}

void ParticleShapeScaleFactory::setFilePath(const char simFile[])
{
    if (!simFile) return;
#if defined(_WIN32) || defined(_WINDLL)
    strncpy_s(m_simFile, NApi::FILE_PATH_MAX_LENGTH, simFile, NApi::FILE_PATH_MAX_LENGTH - 1);
#else
    std::strncpy(m_simFile, simFile, NApi::FILE_PATH_MAX_LENGTH - 1);
#endif
}

bool ParticleShapeScaleFactory::setup(NApiFactory::NApiHelpers::CFlags<EApiParticleFactoryFeatureFlags>& featureFlags,
                                     const char prefFile[],
                                     char customMsg[NApi::ERROR_MSG_MAX_LENGTH])
{
    // Required in EDEM 2026: without this, EDEM can ignore newParticleData.shapeScale
    featureFlags.enableFlag(EApiParticleFactoryFeatureFlags::usesShapeScale);

    // Load preferences. If the file cannot be found, we fail-safe by generating NO particles
    // and we report the exact expected location in customMsg.
    const bool loaded = loadPrefsIfPresent(prefFile);

    if (!loaded)
    {
        // Fail-safe: avoid accidental particle explosion when preferences are missing.
        m_targetNumberPerSecond = 0.0;
        m_targetMassPerSecond = 0.0;
        m_particlesPerTimeStep = 0;
        m_totalNumberLimit = 0;
        m_totalMassLimitKg = 0.0;

        if (customMsg)
        {
            std::snprintf(customMsg, NApi::ERROR_MSG_MAX_LENGTH,
                          "Preference file not found. EDEM asked for: '%s'. "
                          "Put ParticleShapeScaleFactoryPresets.txt under a 'config' folder next to your .dem file, "
                          "e.g. <dem_folder>\\config\\ParticleShapeScaleFactoryPresets.txt",
                          (prefFile ? prefFile : ""));
        }
        return true; // still load plugin, but it will not generate particles
    }

    if (m_typeName[0] == '\0')
    {
        std::snprintf(customMsg, NApi::ERROR_MSG_MAX_LENGTH, "%s", "particleType is empty in preference file.");
        return false;
    }

    if (m_scale <= 0.0) m_scale = 1.0;
    if (m_particlesPerTimeStep < 0) m_particlesPerTimeStep = 0;
    if (m_maxAttemptsToPlace < 1) m_maxAttemptsToPlace = 1;

    // Provide a short confirmation to help you verify which settings are in effect.
    if (customMsg)
    {
        std::snprintf(customMsg, NApi::ERROR_MSG_MAX_LENGTH,
                      "Prefs loaded. particleType=%s, totalNumber=%lld, targetNps=%.6g, startTime=%.6g",
                      m_typeName,
                      (long long)m_totalNumberLimit,
                      m_targetNumberPerSecond,
                      m_startTime);
    }
    return true;
}

bool ParticleShapeScaleFactory::starting()
{
    m_lastTime = -1.0;
    m_prevStepTime = -1.0;
    m_createdThisStep = 0;
    m_quotaThisStep = 0;
    m_rateCarry = 0.0;

    m_totalCreated = 0;
    m_totalMassCreatedKg = 0.0;
    return true;
}

void ParticleShapeScaleFactory::stopping() {}

void ParticleShapeScaleFactory::configForTimeStep(NApiCore::ICustomPropertyDataApi_1_0* /*simData*/) {}

void ParticleShapeScaleFactory::normalizeToPreserveVolume(double& sx, double& sy, double& sz)
{
    const double prod = sx * sy * sz;
    if (prod <= 0.0) return;
    const double g = std::pow(prod, 1.0 / 3.0);
    if (g <= 0.0) return;
    sx /= g;
    sy /= g;
    sz /= g;
}

double ParticleShapeScaleFactory::estimateParticleMassKg(double sx, double sy, double sz) const
{
    // If preserveVolume is enabled, shapeScale should not change volume.
    const double shapeVolMul = (m_preserveVolume ? 1.0 : (sx * sy * sz));
    const double globalVolMul = m_scale * m_scale * m_scale;

    double baseMassKg = 0.0;

    if (m_massPerParticleKg > 0.0)
        baseMassKg = m_massPerParticleKg;
    else if (m_baseMassKg > 0.0)
        baseMassKg = m_baseMassKg;
    else if (m_densityKgPerM3 > 0.0 && m_baseVolumeM3 > 0.0)
        baseMassKg = m_densityKgPerM3 * m_baseVolumeM3;

    if (baseMassKg <= 0.0) return 0.0;

    const double m = baseMassKg * globalVolMul * shapeVolMul;
    return (m > 0.0 ? m : 0.0);
}

int ParticleShapeScaleFactory::computeQuotaThisStep(double timeNow)
{
    // Start time gate
    if (timeNow < m_startTime)
        return 0;

    // Determine dt from time difference
    double dt = 0.0;
    if (m_prevStepTime >= 0.0)
    {
        dt = timeNow - m_prevStepTime;
        if (dt < 0.0) dt = 0.0;
        if (dt > 10.0) dt = 10.0; // safety clamp
    }
    m_prevStepTime = timeNow;

    // Determine number-per-second target
    double rateNps = 0.0;

    if (m_targetMassPerSecond > 0.0)
    {
        const double sxMean = 0.5 * (m_sx.minV + m_sx.maxV);
        const double syMean = 0.5 * (m_sy.minV + m_sy.maxV);
        const double szMean = 0.5 * (m_sz.minV + m_sz.maxV);
        const double meanMass = estimateParticleMassKg(sxMean, syMean, szMean);
        if (meanMass > 0.0)
            rateNps = m_targetMassPerSecond / meanMass;
    }

    if (rateNps <= 0.0 && m_targetNumberPerSecond > 0.0)
        rateNps = m_targetNumberPerSecond;

    int quota = 0;

    if (rateNps > 0.0)
    {
        // Accumulate fractional particles
        m_rateCarry += rateNps * dt;
        if (m_rateCarry < 0.0) m_rateCarry = 0.0;
        quota = static_cast<int>(std::floor(m_rateCarry));
        m_rateCarry -= static_cast<double>(quota);

        // Safety: avoid generating too many in a single time step
        if (quota > 200000) quota = 200000;
    }
    else
    {
        quota = m_particlesPerTimeStep;
    }

    // Apply total number cap (if set)
    if (m_totalNumberLimit > 0)
    {
        const long long remaining = static_cast<long long>(m_totalNumberLimit) - static_cast<long long>(m_totalCreated);
        if (remaining <= 0) return 0;
        if (quota > remaining) quota = static_cast<int>(remaining);
    }

    // Apply total mass cap (if set and mass model is available)
    if (m_totalMassLimitKg > 0.0)
    {
        const double remainingMass = m_totalMassLimitKg - m_totalMassCreatedKg;
        if (remainingMass <= 0.0) return 0;

        const double sxMean = 0.5 * (m_sx.minV + m_sx.maxV);
        const double syMean = 0.5 * (m_sy.minV + m_sy.maxV);
        const double szMean = 0.5 * (m_sz.minV + m_sz.maxV);
        const double meanMass = estimateParticleMassKg(sxMean, syMean, szMean);

        if (meanMass > 0.0)
        {
            const long long remainingN = static_cast<long long>(std::floor(remainingMass / meanMass));
            if (remainingN <= 0) return 0;
            if (quota > remainingN) quota = static_cast<int>(remainingN);
        }
        // If meanMass cannot be estimated, we do not enforce totalMass cap.
    }

    if (quota < 0) quota = 0;
    return quota;
}

NApi::ECalculateResult ParticleShapeScaleFactory::createParticle(
    const NApiFactory::NFactoryTypes::STimeStepData& timeStepData,
    bool& particleCreated,
    bool& additionalParticleRequired,
    NApiFactory::NFactoryTypes::SNewParticleData& newParticleData,
    NApiCore::ICustomPropertyDataApi_1_0* /*propData*/,
    NApiCore::ICustomPropertyDataApi_1_0* /*simData*/)
{
    particleCreated = false;
    additionalParticleRequired = false;

    const double timeNow = timeStepData.time;

    // New time step
    if (m_lastTime < 0.0 || timeNow != m_lastTime)
    {
        m_lastTime = timeNow;
        m_createdThisStep = 0;
        m_quotaThisStep = computeQuotaThisStep(timeNow);
    }

    // Nothing to do this step
    if (m_quotaThisStep <= 0)
        return NApi::eSuccess;

    // Reached this-step quota
    if (m_createdThisStep >= m_quotaThisStep)
        return NApi::eSuccess;

    // Start time gate (extra guard)
    if (timeNow < m_startTime)
        return NApi::eSuccess;

    // --- Random shapeScale ---
    double sx = randUniform(m_sx.minV, m_sx.maxV);
    double sy = randUniform(m_sy.minV, m_sy.maxV);
    double sz = randUniform(m_sz.minV, m_sz.maxV);

    if (m_preserveVolume)
        normalizeToPreserveVolume(sx, sy, sz);

    // --- Random position in box ---
    const double x = randUniform(m_x.minV, m_x.maxV);
    const double y = randUniform(m_y.minV, m_y.maxV);
    const double z = randUniform(m_z.minV, m_z.maxV);

    // Fill newParticleData
    newParticleData.type = m_typeName;
    newParticleData.scale = m_scale;

    newParticleData.position = NApiFactory::NApiHelpers::CSimple3DVector(x, y, z);
    newParticleData.velocity = NApiFactory::NApiHelpers::CSimple3DVector(0.0, 0.0, 0.0);
    newParticleData.angVel   = NApiFactory::NApiHelpers::CSimple3DVector(0.0, 0.0, 0.0);

    // Identity orientation
    newParticleData.orientation = NApiFactory::NApiHelpers::CSimple3x3Matrix(
        1.0, 0.0, 0.0,
        0.0, 1.0, 0.0,
        0.0, 0.0, 1.0
    );

    newParticleData.shapeScale = NApiFactory::NApiHelpers::CSimple3DVector(sx, sy, sz);

    // Mark created
    particleCreated = true;
    ++m_createdThisStep;
    ++m_totalCreated;

    // Accumulate mass (if model available)
    const double m = estimateParticleMassKg(sx, sy, sz);
    if (m > 0.0)
        m_totalMassCreatedKg += m;

    // Check caps after creation
    bool stopNow = false;

    if (m_totalNumberLimit > 0 && static_cast<long long>(m_totalCreated) >= m_totalNumberLimit)
        stopNow = true;

    if (m_totalMassLimitKg > 0.0 && m_totalMassCreatedKg >= m_totalMassLimitKg)
        stopNow = true;

    if (stopNow)
    {
        // stop requesting additional particles in this step
        m_quotaThisStep = m_createdThisStep;
        additionalParticleRequired = false;
        return NApi::eSuccess;
    }

    additionalParticleRequired = (m_createdThisStep < m_quotaThisStep);
    return NApi::eSuccess;
}

void ParticleShapeScaleFactory::getSmallestScale(double& scale, char type[NApi::API_BASIC_STRING_LENGTH]) const
{
    scale = m_scale;
    std::snprintf(type, NApi::API_BASIC_STRING_LENGTH, "%s", m_typeName);
}

void ParticleShapeScaleFactory::getLargestScale(double& scale, char type[NApi::API_BASIC_STRING_LENGTH]) const
{
    scale = m_scale;
    std::snprintf(type, NApi::API_BASIC_STRING_LENGTH, "%s", m_typeName);
}

bool ParticleShapeScaleFactory::loadPrefsIfPresent(const char* prefFilePath)
{
    if (!prefFilePath || !prefFilePath[0]) return false;

    std::ifstream fin(prefFilePath);
    if (!fin.good()) return false;

    // Keys supported:
    //   particleType=ParticleType1
    //   scale=1.0
    //   preserveVolume=0/1
    //
    //   sxMin=0.8  sxMax=1.5
    //   syMin=0.9  syMax=1.2
    //   szMin=0.85 szMax=1.4
    //
    //   boxMin=-0.5 -0.5 -0.5
    //   boxMax= 0.5  0.5  0.5
    //
    // Generation controls:
    //   startTime=0
    //   totalNumber=1000
    //   totalMassKg=100
    //   targetNumberPerSecond=5000
    //   targetMassPerSecond=10
    //   particlesPerTimeStep=50
    //   maxAttemptsToPlace=20
    //
    // Mass model (needed for totalMass/targetMass):
    //   massPerParticleKg=0.0012
    //   baseMassKg=0.0012
    //   densityKgPerM3=1198
    //   baseVolumeM3=1e-6
    //
    // RNG:
    //   seed=1234567
    //   seed=-1

    std::string line;
    while (std::getline(fin, line))
    {
        // strip comments
        auto hash = line.find('#');
        if (hash != std::string::npos) line = line.substr(0, hash);
        line = trim(line);
        if (line.empty()) continue;

        std::string key, value;
        if (!splitKeyValue(line, key, value)) continue;

        if (key == "particleType")
        {
            value = trim(value);
            if (!value.empty())
                std::snprintf(m_typeName, NApi::API_BASIC_STRING_LENGTH, "%s", value.c_str());
            continue;
        }

        if (key == "scale") { m_scale = std::atof(value.c_str()); continue; }
        if (key == "particlesPerTimeStep") { m_particlesPerTimeStep = std::atoi(value.c_str()); continue; }

        if (key == "preserveVolume")
        {
            bool b = m_preserveVolume;
            if (parseBool01(value, b)) m_preserveVolume = b;
            continue;
        }

        if (key == "sxMin") { m_sx.minV = std::atof(value.c_str()); continue; }
        if (key == "sxMax") { m_sx.maxV = std::atof(value.c_str()); continue; }
        if (key == "syMin") { m_sy.minV = std::atof(value.c_str()); continue; }
        if (key == "syMax") { m_sy.maxV = std::atof(value.c_str()); continue; }
        if (key == "szMin") { m_sz.minV = std::atof(value.c_str()); continue; }
        if (key == "szMax") { m_sz.maxV = std::atof(value.c_str()); continue; }

        if (key == "boxMin")
        {
            std::vector<double> vals;
            if (parseDoubles(value, vals) && vals.size() >= 3)
            {
                m_x.minV = vals[0];
                m_y.minV = vals[1];
                m_z.minV = vals[2];
            }
            continue;
        }

        if (key == "boxMax")
        {
            std::vector<double> vals;
            if (parseDoubles(value, vals) && vals.size() >= 3)
            {
                m_x.maxV = vals[0];
                m_y.maxV = vals[1];
                m_z.maxV = vals[2];
            }
            continue;
        }

        // Generation controls
        if (key == "startTime") { m_startTime = std::atof(value.c_str()); continue; }
        if (key == "totalNumber") { m_totalNumberLimit = std::atoll(value.c_str()); continue; }
        if (key == "totalMass" || key == "totalMassKg") { m_totalMassLimitKg = std::atof(value.c_str()); continue; }
        if (key == "targetNumberPerSecond") { m_targetNumberPerSecond = std::atof(value.c_str()); continue; }
        if (key == "targetMassPerSecond") { m_targetMassPerSecond = std::atof(value.c_str()); continue; }
        if (key == "maxAttemptsToPlace") { m_maxAttemptsToPlace = std::atoi(value.c_str()); continue; }

        // Mass model
        if (key == "massPerParticle" || key == "massPerParticleKg") { m_massPerParticleKg = std::atof(value.c_str()); continue; }
        if (key == "baseMassKg") { m_baseMassKg = std::atof(value.c_str()); continue; }
        if (key == "densityKgPerM3") { m_densityKgPerM3 = std::atof(value.c_str()); continue; }
        if (key == "baseVolumeM3") { m_baseVolumeM3 = std::atof(value.c_str()); continue; }

        if (key == "seed")
        {
            const long long s = std::atoll(value.c_str());
            if (s < 0)
            {
                std::random_device rd;
                m_rng.seed(((unsigned long long)rd() << 32) ^ (unsigned long long)rd());
            }
            else
            {
                m_rng.seed(static_cast<unsigned long long>(s));
            }
            continue;
        }

    }

    return true;
}
