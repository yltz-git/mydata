\
# ParticleShapeScaleFactory (EDEM 2026 / API v3.10.0) - VS2022 工程

目标：用 **一个粒子类型**（同一个几何原型），在创建粒子时通过  
`NFactoryTypesV3_10_0::SNewParticleData::shapeScale = (sx,sy,sz)`  
实现“ONLY 1 particle type ↔ 3 shapes”的效果（拉伸/压扁）。

---

## 你应该把这个工程解压到哪里？

建议解压到你指定的目录（这样输出路径正好满足你的要求）：

`D:\EDEM_UDL\ParticleShapeScaleFactory\`

解压后结构应类似：

```
D:\EDEM_UDL\ParticleShapeScaleFactory\
  ParticleShapeScaleFactory.sln
  ParticleShapeScaleFactory.vcxproj
  src\
  config\
  bin\          (编译后自动生成，DLL 会输出到这里)
  tools\
```

> 重要：插件会通过相对路径读取配置文件：
> `..\config\ParticleShapeScaleFactoryPresets.txt`
> 所以 DLL 在 `bin\`，配置在 `config\` 的同级目录是最稳的。

---

## 用中文 VS2022 编译（x64）

1. 双击打开：`ParticleShapeScaleFactory.sln`
2. 顶部选择：
   - **解决方案配置**：Release
   - **解决方案平台**：x64  
     （如果没有 x64：菜单“生成”→“配置管理器”→ 添加 x64）
3. 点击：**生成 → 生成解决方案**

成功后会生成：

`D:\EDEM_UDL\ParticleShapeScaleFactory\bin\ParticleShapeScaleFactory.dll`

---

## 如果编译报 “找不到头文件 Api/...” 怎么办？

本工程默认 include 指向：

`C:\Program Files\Altair\2026\EDEM\src`

如果你的 EDEM 不是装在这个路径（比如装在 E 盘），就改这个设置：

右键项目 → 属性 → **C/C++ → 常规 → 附加包含目录**  
把路径改成你的真实安装路径，例如：

`E:\Program Files\Altair\2026\EDEM\src`

---

## 如何在 EDEM 里使用

### 推荐方式（不依赖 plugins 目录）
在 Creator/Simulator 里加载插件时，直接浏览选择 DLL：

`D:\EDEM_UDL\ParticleShapeScaleFactory\bin\ParticleShapeScaleFactory.dll`

然后运行即可。

### 放到 EDEM 全局 plugins 目录（可选）
你也可以复制下面两个文件到（需要管理员权限）：

```
C:\Program Files\Altair\2026\EDEM\plugins\ParticleShapeScaleFactory\
  ParticleShapeScaleFactory.dll
  ParticleShapeScaleFactory.txt   (可选；某些安装用于扫描列表)
```

如果 EDEM 不识别 `.txt`，直接在 GUI 里加载 DLL 也完全没问题。

---

## 配置：三方向随机缩放 + 盒内随机生成

编辑：

`config\ParticleShapeScaleFactoryPresets.txt`

你需要设置两类参数：

1) **三方向 shapeScale 随机范围**（每个颗粒独立随机组合）：
   - `sxMin/sxMax`
   - `syMin/syMax`
   - `szMin/szMax`

2) **生成区域（Box）**：
   - `boxMin = x y z`
   - `boxMax = x y z`

> EDEM 通常使用 SI 单位（m）。例如中心(0,0,0)，尺寸 1000mm 立方体，应写：
> `boxMin=-0.5 -0.5 -0.5`，`boxMax=0.5 0.5 0.5`。

---

## 常见问题

### 1) EDEM 报找不到配置文件
确认目录结构是：

- DLL：`...\bin\ParticleShapeScaleFactory.dll`
- 配置：`...\config\ParticleShapeScaleFactoryPresets.txt`

且二者同属于同一个工程根目录下。

### 2) 形状方向不对（拉伸方向不符合预期）
`shapeScale` 的 X/Y/Z 是**粒子原型坐标轴**方向，不是全局坐标轴。  
如果你导入多面体时轴向不同，需要调换 (sx,sy,sz) 的分量顺序。

