\
@echo off
setlocal
echo Building ParticleShapeScaleFactory (Release|x64) ...
where devenv >nul 2>nul
if errorlevel 1 (
  echo ERROR: devenv.exe not found. Please run this from "Developer Command Prompt for VS 2022".
  exit /b 1
)
devenv "%~dp0ParticleShapeScaleFactory.sln" /Build "Release|x64"
endlocal
