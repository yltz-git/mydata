@echo off
setlocal

REM Run in Windows CMD.
REM Usage: double-click or run from cmd:  find_shapeScale_cmd.bat

set EDEM_SRC=C:\Program Files\Altair\2026\EDEM\src

if not exist "%EDEM_SRC%" (
  echo [ERROR] Not found: %EDEM_SRC%
  echo Edit this .bat and set EDEM_SRC to your EDEM\src path.
  exit /b 1
)

cd /d "%EDEM_SRC%"

echo === Searching for "ShapeScale" (case-insensitive) in *.h/*.hpp ===
findstr /s /n /i /c:"ShapeScale" *.h *.hpp

echo.
echo === Searching for "shapeScale" (exact token) in *.h/*.hpp ===
findstr /s /n /c:"shapeScale" *.h *.hpp

echo.
echo Done.
pause
endlocal
