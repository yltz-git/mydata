# Run in PowerShell.
# Usage:
#   cd "C:\Program Files\Altair\2026\EDEM\src"
#   .\find_shapeScale_ps1.ps1

$EDEM_SRC = "C:\Program Files\Altair\2026\EDEM\src"
if (-not (Test-Path $EDEM_SRC)) {
  Write-Error "Not found: $EDEM_SRC. Edit the script and fix the path."
  exit 1
}

Set-Location $EDEM_SRC

Write-Host "=== Select-String: ShapeScale in *.h/*.hpp ==="
Get-ChildItem -Recurse -Include *.h, *.hpp | Select-String -Pattern "ShapeScale" | Select-Object -First 200

Write-Host "=== Select-String: shapeScale in *.h/*.hpp ==="
Get-ChildItem -Recurse -Include *.h, *.hpp | Select-String -Pattern "shapeScale" | Select-Object -First 200
