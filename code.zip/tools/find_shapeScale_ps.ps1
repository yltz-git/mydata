# Run in PowerShell.
# Usage: right click -> Run with PowerShell

$EDEM_SRC = "C:\Program Files\Altair\2026\EDEM\src"
if (!(Test-Path $EDEM_SRC)) {
  Write-Host "[ERROR] Not found: $EDEM_SRC" -ForegroundColor Red
  Write-Host "Edit this .ps1 and set EDEM_SRC to your EDEM\\src path."
  exit 1
}

Set-Location $EDEM_SRC
Write-Host "=== Searching for ShapeScale in *.h/*.hpp ==="
Get-ChildItem -Recurse -Include *.h,*.hpp | Select-String -Pattern "ShapeScale" | Select-Object -First 200
